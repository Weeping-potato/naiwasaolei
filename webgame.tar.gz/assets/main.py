# -*- coding: utf-8 -*-
"""
扫雷游戏（Python + Pygame）
===========================
操作说明：
    左键  —— 翻开格子
    右键  —— 插旗 / 取消插旗
    点顶部中间的圆脸按钮 —— 重开本局
    ESC   —— 回到难度选择菜单
规则：
    第一次点击绝不会踩雷；踩中地雷游戏结束；
    翻开所有不是地雷的格子即获胜。
难度：
    低 9×9 / 10 雷；中 16×16 / 40 雷；高 30×16 / 99 雷。
说明：
    默认使用代码内置绘制的简易炸弹图形，不需要任何外部图片文件；
    也可以把 BOMB_IMAGE_PATH 指到自己的图片（见下面注释）。
"""

import asyncio
import os
import sys
import random
import pygame

# ============================================================
# ==================== 可调参数 ==============================
# ============================================================
CELL = 32                        # 每个格子的像素大小
TOP_BAR = 56                     # 顶部信息栏高度
MENU_W, MENU_H = 420, 340        # 难度选择菜单窗口大小

# 难度配置：(名称, 列数, 行数, 地雷数)
DIFFICULTIES = [
    ("低", 9,  9,  10),
    ("中", 16, 16, 40),
    ("高", 30, 16, 99),
]

# 当前难度（运行时随玩家选择而改变）
COLS, ROWS, MINES = 9, 9, 10

# ============================================================
# ========== 炸弹素材配置（想换炸弹形象只改这一行） ============
# ------------------------------------------------------------
# 默认 None：使用下面代码用 pygame 画出来的简易炸弹。
#   → 不依赖外部文件，打包 exe 后素材不会丢。
# 想换成自己的炸弹图片：把下一行改成图片路径即可，例如：
#       BOMB_IMAGE_PATH = "bomb.jpg"
#   图片会自动缩放到格子大小；建议用正方形 PNG（带透明背景）。
# ============================================================
BOMB_IMAGE_PATH = "bomb.jpg"

# 难度选择菜单的背景图（同样用 resource_path 加载，打包后不会丢）
MENU_BG_PATH = "menu_bg.jpg"
# 顶部中间重置按钮的两张脸：正常进行中 / 踩雷失败
FACE_PLAY_PATH = "face_play.jpg"
FACE_DEAD_PATH = "face_dead.jpg"
# 顶部左侧显示的小图标（None = 显示剩余雷数数字；想换图就填文件名）
LEFT_ICON_PATH = None
# 右键插旗时显示的小旗
FLAG_IMG_PATH = "flag.png"
# ============================================================

# -------------------- 颜色（奶蛙暖色系：奶油黄底 + 暖棕边框） --------------------
COLOR_BG         = (232, 224, 200)   # 整体背景：奶油色
COLOR_CELL       = (232, 224, 200)   # 未翻开格子底色
COLOR_CELL_LIGHT = (250, 246, 230)   # 凸起亮边（奶白）
COLOR_CELL_DARK  = (166, 155, 128)   # 凸起暗边（暖棕）
COLOR_OPEN       = (243, 238, 220)   # 已翻开格子底色（更浅的奶油色）
COLOR_BAR        = (146, 134, 108)   # 顶部信息栏底色（奶蛙手的暖棕）
COLOR_BTN_HOVER  = (218, 208, 180)   # 菜单按钮悬停色

# 1~8 数字的经典配色
NUMBER_COLORS = {
    1: (0,   0,   255),
    2: (0,   128, 0),
    3: (255, 0,   0),
    4: (0,   0,   128),
    5: (128, 0,   0),
    6: (0,   128, 128),
    7: (0,   0,   0),
    8: (128, 128, 128),
}


# ============================================================
# ==================== 资源与字体 =============================
# ============================================================
def resource_path(relative):
    """兼容“开发环境直接运行”和“PyInstaller 打包成 exe”两种情况。
    打包后资源被解压到 sys._MEIPASS 临时目录，必须去那里找图片，
    而不是按双击 exe 时的当前工作目录找。"""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative)
    if sys.platform == "emscripten":
        # Web 版：资源直接以相对路径挂在虚拟文件系统上
        return relative
    return os.path.join(os.path.abspath("."), relative)


def get_font(size):
    """获取字体：优先用 Windows 自带中文字体（直接读 ttf 文件，
    不调用会枚举系统注册表的 SysFont，避免之前遇到的报错）；
    都失败就退回 pygame 内置字体（仅能显示数字/英文）。"""
    for path in (r"C:\Windows\Fonts\msyh.ttc",
                 r"C:\Windows\Fonts\simhei.ttf",
                 r"C:\Windows\Fonts\simsun.ttc",
                 "font_cn.otf"):
        try:
            return pygame.font.Font(path, size)
        except Exception:
            continue
    return pygame.font.Font(None, size)


# ============================================================
# ==================== 炸弹素材 ===============================
# ============================================================
def load_bomb_image():
    """加载外部炸弹图片。
    若 BOMB_IMAGE_PATH 为 None 或文件加载失败，返回 None，
    主程序随后会改用内置绘制的简易炸弹。"""
    if not BOMB_IMAGE_PATH:
        return None
    try:
        # jpg 没有透明通道，先转成可做“色键透明”的格式
        img = pygame.image.load(resource_path(BOMB_IMAGE_PATH)).convert()
        # 把纯白色背景抠成透明，避免贴在灰色格子上出现一块白方块
        img.set_colorkey((255, 255, 255))
        img = img.convert_alpha()
        return pygame.transform.scale(img, (CELL - 8, CELL - 8))
    except Exception as e:
        print(f"[警告] 炸弹图片加载失败（{BOMB_IMAGE_PATH}），改用内置绘制：{e}")
        return None


def load_menu_bg():
    """加载难度菜单背景图，缩放到菜单窗口大小，并做强模糊——
    背景是一张棋盘截图，模糊后棋盘网格线消失，只留下角色轮廓氛围；
    失败返回 None。"""
    if not MENU_BG_PATH:
        return None
    try:
        img = pygame.image.load(resource_path(MENU_BG_PATH)).convert()
        img = pygame.transform.scale(img, (MENU_W, MENU_H))
        small = pygame.transform.smoothscale(img, (MENU_W // 10, MENU_H // 10))
        return pygame.transform.smoothscale(small, (MENU_W, MENU_H))
    except Exception as e:
        print(f"[警告] 菜单背景加载失败（{MENU_BG_PATH}），改用纯色背景：{e}")
        return None


def load_face_images():
    """加载顶部重置按钮的两张脸，缩放到按钮大小。
    返回 (正常脸, 踩雷脸)；某张加载失败就对应位置返回 None。"""
    def _load(path):
        try:
            img = pygame.image.load(resource_path(path))
            img = pygame.transform.scale(img, (50, TOP_BAR - 16))
            return whiten_to_alpha(img)
        except Exception as e:
            print(f"[警告] 按钮图片加载失败（{path}）：{e}")
            return None
    return _load(FACE_PLAY_PATH), _load(FACE_DEAD_PATH)


def whiten_to_alpha(img, thresh=228):
    """把图片四角连通的白色背景抠成透明。
    用 flood fill 而不是全图见白就抠：这样小黄人身上的浅色、
    大笑脸的白牙等孤立白色区域不会被误抠出洞，边缘也更干净。
    请在图片缩放到小尺寸后再调用。"""
    from collections import deque
    img = img.convert_alpha()
    w, h = img.get_size()
    visited = [[False] * h for _ in range(w)]
    q = deque()
    # 从四个角出发（角落一般都是背景）
    for sx, sy in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        r, g, b, _ = img.get_at((sx, sy))
        if r > thresh and g > thresh and b > thresh and not visited[sx][sy]:
            visited[sx][sy] = True
            q.append((sx, sy))
    while q:
        x, y = q.popleft()
        img.set_at((x, y), (0, 0, 0, 0))
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h and not visited[nx][ny]:
                r, g, b, a = img.get_at((nx, ny))
                if r > thresh and g > thresh and b > thresh:
                    visited[nx][ny] = True
                    q.append((nx, ny))
    return img


def load_left_icon():
    """加载顶部左侧小图标，缩放到顶栏高度；白底抠透明。失败返回 None。"""
    if not LEFT_ICON_PATH:
        return None
    try:
        img = pygame.image.load(resource_path(LEFT_ICON_PATH))
        img = pygame.transform.scale(img, (TOP_BAR - 12, TOP_BAR - 12))
        return whiten_to_alpha(img)
    except Exception as e:
        print(f"[警告] 左侧图标加载失败（{LEFT_ICON_PATH}）：{e}")
        return None


def load_flag_image():
    """加载右键插旗的小旗图，缩放到格子大小；白底抠透明。失败返回 None。"""
    if not FLAG_IMG_PATH:
        return None
    try:
        img = pygame.image.load(resource_path(FLAG_IMG_PATH))
        img = pygame.transform.scale(img, (CELL - 2, CELL - 2))
        return whiten_to_alpha(img)
    except Exception as e:
        print(f"[警告] 旗帜图片加载失败（{FLAG_IMG_PATH}）：{e}")
        return None


def draw_led(screen, margin_x, text, font, align="left"):
    """奶蛙风格的计数器：深棕圆角底 + 奶蛙黄数字。align 决定 margin_x 是左/右留白。"""
    txt = font.render(text, True, (255, 217, 74))
    box = pygame.Rect(0, 0, txt.get_width() + 16, txt.get_height() + 10)
    if align == "right":
        box.topright = (COLS * CELL - margin_x, 0)
    else:
        box.topleft = (margin_x, 0)
    box.centery = TOP_BAR // 2
    pygame.draw.rect(screen, (70, 58, 32), box, border_radius=8)
    pygame.draw.rect(screen, (166, 155, 128), box, 2, border_radius=8)
    screen.blit(txt, txt.get_rect(center=box.center))


def draw_bomb_surface(size):
    """不依赖外部文件时，用 pygame 画一个简易炸弹，返回一个 Surface。
    黑圆弹体 + 白色高光点 + 引线和火花。"""
    s = pygame.Surface((size, size), pygame.SRCALPHA)   # 透明背景
    cx, cy = size // 2, size // 2 + 1
    r = size // 2 - 2
    pygame.draw.circle(s, (20, 20, 20), (cx, cy), r)
    pygame.draw.circle(s, (200, 200, 200),
                       (cx - r // 3, cy - r // 3), max(2, r // 5))
    pygame.draw.line(s, (120, 80, 20),
                     (cx + r // 2, cy - r + 2),
                     (cx + r + 2,  cy - r - 4), 2)
    pygame.draw.circle(s, (255, 160, 0),
                       (cx + r + 3, cy - r - 5), 2)
    return s


# ============================================================
# ==================== 棋盘数据结构 ===========================
# ============================================================
class Cell:
    """一个格子的状态。"""
    __slots__ = ("mine", "revealed", "flagged", "adj")

    def __init__(self):
        self.mine = False       # 是否是地雷
        self.revealed = False   # 是否已被翻开
        self.flagged = False    # 是否被插了旗
        self.adj = 0            # 周围 8 格中的地雷数


def make_board():
    """生成一个空棋盘（还没布雷）。"""
    return [[Cell() for _ in range(COLS)] for _ in range(ROWS)]


def place_mines(board, safe_r, safe_c):
    """首次点击后才布雷，并且保证 (safe_r, safe_c) 及其周围一圈没有雷。"""
    forbidden = {(safe_r + dr, safe_c + dc)
                 for dr in (-1, 0, 1) for dc in (-1, 0, 1)}
    candidates = [(r, c) for r in range(ROWS) for c in range(COLS)
                  if (r, c) not in forbidden]
    if len(candidates) < MINES:
        candidates = [(r, c) for r in range(ROWS) for c in range(COLS)
                      if (r, c) != (safe_r, safe_c)]

    for r, c in random.sample(candidates, MINES):
        board[r][c].mine = True

    for r in range(ROWS):
        for c in range(COLS):
            if board[r][c].mine:
                continue
            n = 0
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < ROWS and 0 <= nc < COLS and board[nr][nc].mine:
                        n += 1
            board[r][c].adj = n


def reveal_cell(board, r, c):
    """翻开 (r,c)；如果它周围雷数为 0，就自动向四周扩散翻开。"""
    stack = [(r, c)]
    while stack:
        cr, cc = stack.pop()
        cur = board[cr][cc]
        if cur.revealed or cur.flagged or cur.mine:
            continue
        cur.revealed = True
        if cur.adj == 0:
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    nr, nc = cr + dr, cc + dc
                    if 0 <= nr < ROWS and 0 <= nc < COLS:
                        nxt = board[nr][nc]
                        if not nxt.revealed and not nxt.flagged and not nxt.mine:
                            stack.append((nr, nc))


# ============================================================
# ==================== 顶部圆脸按钮 ===========================
# ============================================================
def draw_face(screen, rect, state):
    """画顶部中间那个圆脸按钮。
    state: 'play'（正常微笑）/ 'win'（戴墨镜）/ 'dead'（难过）"""
    cx, cy = rect.centerx, rect.centery
    r = min(rect.width, rect.height) // 2 - 3
    pygame.draw.circle(screen, (255, 220, 0), (cx, cy), r)
    pygame.draw.circle(screen, (0, 0, 0), (cx, cy), r, 1)
    pygame.draw.circle(screen, (0, 0, 0), (cx - r // 3, cy - r // 4), 2)
    pygame.draw.circle(screen, (0, 0, 0), (cx + r // 3, cy - r // 4), 2)
    if state == "win":
        pygame.draw.rect(screen, (0, 0, 0),
                         (cx - r // 2, cy - r // 3, r, r // 4))
        pygame.draw.rect(screen, (0, 0, 0),
                         (cx + r // 2 - r, cy - r // 3, r, r // 4))
        pygame.draw.arc(screen, (0, 0, 0),
                        (cx - r // 2, cy - r // 6, r, r), 0, 3.14)
    elif state == "dead":
        pygame.draw.arc(screen, (0, 0, 0),
                        (cx - r // 2, cy, r, r), 3.14, 6.28)
    else:
        pygame.draw.arc(screen, (0, 0, 0),
                        (cx - r // 2, cy - r // 6, r, r), 0, 3.14)


# ============================================================
# ==================== 主程序 ================================
# ============================================================
async def main():
    global COLS, ROWS, MINES

    pygame.init()
    # Web 端每次加载随机种子相同，用页面运行毫秒数重播种子，保证每局布雷不同
    random.seed(pygame.time.get_ticks() + random.getrandbits(16))
    # 先建窗口(convert_alpha 需要显示模式已建立),再设图标
    # RESIZABLE:允许拖动窗口边缘自由拉伸大小
    window = pygame.display.set_mode((MENU_W, MENU_H), pygame.RESIZABLE)
    pygame.display.set_caption("奶蛙扫雷")
    # 窗口左上角 / 任务栏图标
    try:
        win_icon = pygame.image.load(resource_path("game_icon.png")).convert_alpha()
        pygame.display.set_icon(win_icon)
    except Exception as e:
        print(f"[提示] 窗口图标加载失败：{e}")
    clock = pygame.time.Clock()

    # 字体
    title_font = get_font(44)
    menu_font = get_font(24)
    small_font = get_font(18)
    game_font = get_font(22)

    # 准备炸弹图：优先外部图片，没有就用内置绘制
    bomb_img = load_bomb_image()
    if bomb_img is None:
        bomb_img = draw_bomb_surface(CELL - 8)

    # 准备菜单背景图
    menu_bg = load_menu_bg()
    # 半透明灰遮罩，盖在背景图上，让标题和按钮看得清
    menu_overlay = pygame.Surface((MENU_W, MENU_H))
    menu_overlay.set_alpha(130)
    menu_overlay.fill((138, 128, 106))

    # 顶部重置按钮的两张脸（正常 / 踩雷）
    face_play_img, face_dead_img = load_face_images()
    # 顶部左侧小图标
    left_icon = load_left_icon()
    # 右键插旗的小旗
    flag_img = load_flag_image()
    # 爆炸音效（踩雷时播放）
    boom_sound = None
    for boom_name in ("explosion.ogg", "explosion.wav"):
        try:
            boom_sound = pygame.mixer.Sound(resource_path(boom_name))
            break
        except Exception:
            continue
    if boom_sound is None:
        print("[提示] 爆炸音效加载失败")

    # ---- 游戏状态 ----
    state = "menu"        # menu = 难度选择；playing = 对局中
    flag_mode = False     # 插旗模式（手机没有右键，点此按钮后点格子即插旗）
    board = None
    started = False       # 第一次左键后才布雷、才开始计时
    game_over = False
    win = False
    flags = 0
    start_ticks = 0
    elapsed = 0

    def start_game(cols, rows, mines):
        """按指定难度开新局：改全局尺寸、调整窗口大小、重置棋盘。"""
        nonlocal board, started, game_over, win, flags, start_ticks, elapsed
        nonlocal flag_mode
        global COLS, ROWS, MINES
        COLS, ROWS, MINES = cols, rows, mines
        w, h = COLS * CELL, ROWS * CELL + TOP_BAR
        pygame.display.set_mode((w, h), pygame.RESIZABLE)
        board = make_board()
        started = game_over = win = False
        flags = 0
        flag_mode = False
        start_ticks = elapsed = 0

    def back_to_menu():
        """回到难度选择菜单，窗口缩回菜单大小。"""
        nonlocal state
        state = "menu"
        pygame.display.set_mode((MENU_W, MENU_H), pygame.RESIZABLE)

    def to_logical(pos, log_w, log_h):
        """窗口坐标 → 逻辑画布坐标（内容等比缩放居中后的逆映射）。"""
        ww, wh = window.get_size()
        s = min(ww / log_w, wh / log_h)
        ox = int((ww - log_w * s) / 2)
        oy = int((wh - log_h * s) / 2)
        return int((pos[0] - ox) / s), int((pos[1] - oy) / s)

    # 预先算好菜单上三个难度按钮的位置
    btn_w, btn_h = 280, 56
    gap = 18
    total_h = len(DIFFICULTIES) * btn_h + (len(DIFFICULTIES) - 1) * gap
    menu_btns = []
    for i, (name, c, r, m) in enumerate(DIFFICULTIES):
        x = (MENU_W - btn_w) // 2
        y = 110 + i * (btn_h + gap)
        menu_btns.append((pygame.Rect(x, y, btn_w, btn_h), name, c, r, m))

    running = True
    while running:
        # 计时（对局中、未结束时才走表）
        if state == "playing" and started and not game_over and not win:
            elapsed = (pygame.time.get_ticks() - start_ticks) // 1000

        # 本帧逻辑画布尺寸：菜单固定；对局随棋盘大小
        if state == "menu":
            log_w, log_h = MENU_W, MENU_H
        else:
            log_w, log_h = COLS * CELL, TOP_BAR + ROWS * CELL
        mouse_x, mouse_y = to_logical(pygame.mouse.get_pos(), log_w, log_h)

        # ---------- 事件处理 ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and state == "playing":
                    back_to_menu()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = to_logical(event.pos, log_w, log_h)

                if state == "menu":
                    # 点菜单按钮 → 开始对应难度
                    for rect, name, c, r, m in menu_btns:
                        if rect.collidepoint(mx, my):
                            start_game(c, r, m)
                            state = "playing"
                    continue

                # ---- 对局中 ----
                # 顶栏可点：旗子按钮切换插旗模式（手机无右键），中间脸重开本局，
                # 右侧计时器区域回菜单
                if my < TOP_BAR:
                    flag_btn = pygame.Rect(COLS * CELL // 2 - 25 - 54, 6, 44, TOP_BAR - 12)
                    btn = pygame.Rect(COLS * CELL // 2 - 25, 8, 50, TOP_BAR - 16)
                    timer = pygame.Rect(COLS * CELL - 70, 0, 70, TOP_BAR)
                    if flag_btn.collidepoint(mx, my):
                        flag_mode = not flag_mode
                    elif btn.collidepoint(mx, my):
                        start_game(COLS, ROWS, MINES)
                    elif timer.collidepoint(mx, my):
                        back_to_menu()
                    continue

                if game_over or win:
                    continue

                c = mx // CELL
                r = (my - TOP_BAR) // CELL
                if not (0 <= r < ROWS and 0 <= c < COLS):
                    continue
                cell = board[r][c]

                if event.button == 1:
                    # 插旗模式（手机适配）：点未翻开的格子 = 插旗/拔旗
                    if flag_mode:
                        if cell.revealed:
                            continue
                        if not cell.flagged and flags >= MINES:
                            continue
                        cell.flagged = not cell.flagged
                        flags += 1 if cell.flagged else -1
                        continue

                    if cell.flagged:
                        continue
                    if not started:
                        place_mines(board, r, c)
                        started = True
                        start_ticks = pygame.time.get_ticks()

                    if cell.mine:
                        game_over = True
                        cell.revealed = True
                        if boom_sound is not None:
                            boom_sound.play()
                        for rr in range(ROWS):
                            for cc in range(COLS):
                                if board[rr][cc].mine and not board[rr][cc].flagged:
                                    board[rr][cc].revealed = True
                    else:
                        reveal_cell(board, r, c)
                        safe_total = ROWS * COLS - MINES
                        opened = sum(
                            1 for rr in range(ROWS) for cc in range(COLS)
                            if board[rr][cc].revealed and not board[rr][cc].mine
                        )
                        if opened == safe_total:
                            win = True
                            flags = MINES

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
                # 右键插旗只在对局中有效
                if state != "playing" or game_over or win:
                    continue
                mx, my = to_logical(event.pos, log_w, log_h)
                if my < TOP_BAR:
                    continue
                c = mx // CELL
                r = (my - TOP_BAR) // CELL
                if not (0 <= r < ROWS and 0 <= c < COLS):
                    continue
                cell = board[r][c]
                if cell.revealed:
                    continue
                if not cell.flagged and flags >= MINES:
                    continue
                cell.flagged = not cell.flagged
                flags += 1 if cell.flagged else -1

        # ============ 绘制 ============
        # 所有内容先画到固定尺寸的逻辑画布上，帧末再整体缩放到窗口
        # （事件处理中可能切换了 menu/playing 状态，这里按当前状态重算）
        if state == "menu":
            log_w, log_h = MENU_W, MENU_H
        else:
            log_w, log_h = COLS * CELL, TOP_BAR + ROWS * CELL
        screen = pygame.Surface((log_w, log_h))
        screen.fill(COLOR_BG)

        if state == "menu":
            # ---- 画难度选择菜单 ----
            # 先铺背景图，再压一层半透明灰，保证文字按钮可读
            if menu_bg is not None:
                screen.blit(menu_bg, (0, 0))
                screen.blit(menu_overlay, (0, 0))
            else:
                screen.fill(COLOR_BG)
            # 标题区垫一块半透明深色圆角横幅,奶蛙黄字在任何背景上都清晰
            banner = pygame.Surface((340, 96), pygame.SRCALPHA)
            pygame.draw.rect(banner, (70, 58, 32, 150), (0, 0, 340, 96),
                             border_radius=14)
            screen.blit(banner, ((MENU_W - 340) // 2, 16))
            title = title_font.render("奶蛙扫雷", True, (255, 217, 74))
            shadow = title_font.render("奶蛙扫雷", True, (70, 58, 32))
            tx = (MENU_W - title.get_width()) // 2
            screen.blit(shadow, (tx + 3, 33))
            screen.blit(title, (tx, 30))
            tip = small_font.render("选择难度开始游戏", True, (240, 240, 240))
            tip_shadow = small_font.render("选择难度开始游戏", True, (70, 58, 32))
            tip_x = (MENU_W - tip.get_width()) // 2
            screen.blit(tip_shadow, (tip_x + 2, 84))
            screen.blit(tip, (tip_x, 82))

            for rect, name, c, r, m in menu_btns:
                hover = rect.collidepoint(mouse_x, mouse_y)
                pygame.draw.rect(screen, COLOR_BTN_HOVER if hover else COLOR_CELL, rect)
                # 经典扫雷凸起效果：上/左亮边，下/右暗边（逐边画线，
                # 不能用 rect.move 平移整个矩形画轮廓——那会把多余的三条边画到按钮外面）
                pygame.draw.line(screen, COLOR_CELL_LIGHT,
                                 rect.topleft, rect.topright, 2)
                pygame.draw.line(screen, COLOR_CELL_LIGHT,
                                 rect.topleft, rect.bottomleft, 2)
                pygame.draw.line(screen, COLOR_CELL_DARK,
                                 rect.bottomleft, rect.bottomright, 2)
                pygame.draw.line(screen, COLOR_CELL_DARK,
                                 rect.topright, rect.bottomright, 2)
                label = menu_font.render(f"{name}   {c}×{r} · {m}雷",
                                         True, (20, 20, 20))
                screen.blit(label,
                            (rect.centerx - label.get_width() // 2,
                             rect.centery - label.get_height() // 2))

        else:
            # ---- 画对局 ----
            # 顶部信息栏
            top_w = COLS * CELL
            pygame.draw.rect(screen, COLOR_BAR, (0, 0, top_w, TOP_BAR))

            # 左侧：小图标（加载失败时显示奶蛙风格的剩余雷数）
            if left_icon is not None:
                screen.blit(left_icon, (8, TOP_BAR // 2 - left_icon.get_height() // 2))
            else:
                remain = MINES - flags
                draw_led(screen, 6, f"{remain:03d}", game_font)

            # 插旗模式按钮（脸的左侧）：手机上没有右键，点它切换“点格子=插旗”
            flag_btn = pygame.Rect(top_w // 2 - 25 - 57, 6, 44, TOP_BAR - 12)
            if flag_mode:
                pygame.draw.rect(screen, (255, 217, 74), flag_btn, border_radius=8)
                pygame.draw.rect(screen, (70, 58, 32), flag_btn, 2, border_radius=8)
            else:
                pygame.draw.rect(screen, COLOR_CELL, flag_btn, border_radius=8)
                pygame.draw.rect(screen, COLOR_CELL_LIGHT, flag_btn, 2, border_radius=8)
                pygame.draw.rect(screen, COLOR_CELL_DARK, flag_btn, 1, border_radius=8)
            if flag_img is not None:
                fimg = pygame.transform.smoothscale(flag_img, (24, 24))
                screen.blit(fimg, fimg.get_rect(center=flag_btn.center))
            else:
                cx2, ty2 = flag_btn.centerx - 4, flag_btn.top + 6
                pygame.draw.line(screen, (80, 80, 80),
                                 (cx2, ty2), (cx2, flag_btn.bottom - 6), 2)
                pygame.draw.polygon(screen, (220, 30, 30), [
                    (cx2, ty2), (cx2 + 16, ty2 + 5), (cx2, ty2 + 10),
                ])

            # 中间：重置按钮（用小黄人脸图片）
            btn_rect = pygame.Rect(top_w // 2 - 25, 8, 50, TOP_BAR - 16)
            face_img = face_dead_img if game_over else face_play_img
            if face_img is not None:
                screen.blit(face_img, btn_rect.topleft)
            else:
                # 图片缺失时回退到代码画的圆脸
                pygame.draw.rect(screen, COLOR_CELL, btn_rect)
                pygame.draw.rect(screen, COLOR_CELL_LIGHT, btn_rect, 2)
                fstate = "win" if win else ("dead" if game_over else "play")
                draw_face(screen, btn_rect, fstate)

            # 右侧：计时器
            draw_led(screen, 6, f"{elapsed:03d}", game_font, align="right")

            # 棋盘
            for r in range(ROWS):
                for c in range(COLS):
                    cell = board[r][c]
                    x = c * CELL
                    y = TOP_BAR + r * CELL
                    rect = pygame.Rect(x, y, CELL, CELL)

                    if cell.revealed:
                        pygame.draw.rect(screen, COLOR_OPEN, rect)
                        pygame.draw.rect(screen, COLOR_CELL_DARK, rect, 1)
                        if cell.mine:
                            screen.blit(bomb_img, (x + 4, y + 4))
                        elif cell.adj > 0:
                            n = game_font.render(str(cell.adj), True,
                                                 NUMBER_COLORS[cell.adj])
                            screen.blit(n, (x + CELL // 2 - n.get_width() // 2,
                                            y + CELL // 2 - n.get_height() // 2))
                    else:
                        pygame.draw.rect(screen, COLOR_CELL, rect)
                        pygame.draw.line(screen, COLOR_CELL_LIGHT,
                                         rect.topleft, rect.bottomleft, 2)
                        pygame.draw.line(screen, COLOR_CELL_LIGHT,
                                         rect.topleft, rect.topright, 2)
                        pygame.draw.line(screen, COLOR_CELL_DARK,
                                         rect.bottomleft, rect.bottomright, 2)
                        pygame.draw.line(screen, COLOR_CELL_DARK,
                                         rect.topright, rect.bottomright, 2)
                        if cell.flagged:
                            if flag_img is not None:
                                # 用图片小旗居中贴在格子里
                                screen.blit(flag_img,
                                            (x + (CELL - flag_img.get_width()) // 2,
                                             y + (CELL - flag_img.get_height()) // 2))
                            else:
                                # 图片缺失时回退到代码画的小红旗
                                pole_x = x + CELL // 2
                                pygame.draw.line(screen, (80, 80, 80),
                                                 (pole_x, y + 6),
                                                 (pole_x, y + CELL - 8), 2)
                                pygame.draw.polygon(screen, (220, 30, 30), [
                                    (pole_x, y + 6),
                                    (pole_x + 10, y + 10),
                                    (pole_x, y + 14),
                                ])
                                pygame.draw.circle(screen, (60, 60, 60),
                                                   (pole_x, y + CELL - 7), 2)

        # 把逻辑画布等比缩放到当前窗口大小，居中显示
        win_w, win_h = window.get_size()
        s = min(win_w / log_w, win_h / log_h)
        sw, sh = max(1, int(log_w * s)), max(1, int(log_h * s))
        scaled = pygame.transform.smoothscale(screen, (sw, sh))
        window.fill(COLOR_BG)
        window.blit(scaled, ((win_w - sw) // 2, (win_h - sh) // 2))

        pygame.display.flip()
        clock.tick(30)
        # Web(pygbag)端必须每帧让出控制权给浏览器事件循环
        await asyncio.sleep(0)

    pygame.quit()
    if sys.platform != "emscripten":
        sys.exit()


if __name__ == "__main__":
    asyncio.run(main())
